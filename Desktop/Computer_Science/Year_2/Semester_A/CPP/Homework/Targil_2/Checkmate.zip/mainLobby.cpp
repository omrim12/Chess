#include "Board.h"
#include <iostream>

using namespace std;

int main() {

	Board *chess = new Board();
	chess->Play();
	//chess->test();
	return 0;

}
